# Contributing

Thanks for helping! GPU Shepherd aims to stay small and easy to read.

## Setup

```bash
pip install -e ".[dev]"
pytest
gpu-shepherd --demo --port 8090     # no Docker or GPU needed; log in as admin / demo-password
```

## Guidelines

- Keep the scheduler pure: no I/O in `scheduler.py`. New GPU behaviour comes with tests.
- New settings get a form in the UI, a pydantic field with validation, and sensible defaults so
  existing YAML files keep loading.
- No JavaScript build step. Prefer htmx attributes and server-rendered templates; keep
  `static/app.js` small and free of inline scripts (the CSP forbids them).
- User-facing text: plain language, say what will happen and why.
- Security: every state-changing route is `POST`, requires a login, and must be called by htmx
  (the `HX-Request` header). Validate anything that ends up in a Docker call.

## Pull requests

Run `pytest` and try your change in demo mode. Describe what you changed and how you tested it;
screenshots help for UI changes.

By contributing you agree that your contributions are licensed under the Apache License 2.0.
